#ifndef RES_H
#define RES_H

#define IDI_MYICON  101

#endif
